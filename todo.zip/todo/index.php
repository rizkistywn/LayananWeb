<?php
// initialize errors variable
$errors = "";

// connect to database
$db = mysqli_connect("localhost", "root", "", "todo");

// insert a quote if submit button is clicked
if (isset($_POST['submit'])) {
    if (empty($_POST['task'])) {
        $errors = "You must fill in the task";
    } else {
        $task = $_POST['task'];
        $sql = "INSERT INTO tasks (task) VALUES ('$task')";
        mysqli_query($db, $sql);
        header('location: index.php');
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>ToDoListIkiii</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <div class="heading">
        <h2 style="font-family: 'Helvetica';">Aplikasi Sederhana ToDoList PHP</h2>
    </div>
    <form method="post" action="index.php" class="input_form">
        <input type="text" name="task" class="task_input">
        <button type="submit" name="submit" id="add_btn" class="add_btn">Tambah</button>
    </form>

    <table>
        <thead>
            <tr>
                <th style="width: 10; text-align: center;">Nomor</th>
                <th style="width: 100; text-align: center;">Mata Kuliah</th>
                <th style="width: 10; text-align: center;">Aksi</th>
            </tr>
        </thead>

        <tbody>
            <?php
            // select all tasks if the page is visited or refreshed
            $tasks = mysqli_query($db, "SELECT * FROM tasks");

            $i = 1;
            while ($row = mysqli_fetch_array($tasks)) { ?>
                <tr>
                    <td style="text-align: center;"> <?php echo $i; ?> </td>
                    <td class="task"> <?php echo $row['task']; ?> </td>
                    <td class="delete" style="text-align: center;">
                        <a href="index.php?del_task=<?php echo $row['id'] ?>">x</a>
                    </td>
                </tr>
            <?php $i++;
            } ?>
        </tbody>
    </table>

    <?php if (isset($errors)) { ?>
        <p><?php echo $errors; ?></p>
    <?php }
    if (isset($_GET['del_task'])) {
        $id = $_GET['del_task'];

        mysqli_query($db, "DELETE FROM tasks WHERE id=" . $id);
        header('location: index.php');
    }
    ?>

</body>

<footer style="text-align: center; margin-top: 20px;">
    <p><b>&copy; <?php echo date("Y"); ?> ToDoList anu Iki.</b></p>
</footer>

</html>